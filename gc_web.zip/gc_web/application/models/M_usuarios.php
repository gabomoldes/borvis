<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_usuarios extends CI_Model {

    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    function login($username, $password) {
//si nos devuelve una fila es porque existe
        $this->db->where('username', $username);
        $this->db->where('password', $password);

        $query = $this->db->get('usuarios');
        if ($query->num_rows() > 0) {
            $this->alta_sesion($username);
            return true;
        } else {
            return false;
        }
    }

    function alta_sesion($username) {
        $this->db->where('username', $username);
        $session_up = array('identificador' => '1');
        $this->db->update('sesiones', $session_up);
        return;
    }

    function baja_sesion($username) {
        $this->db->where('username', $username);
        $session_down = array('identificador' => '0');
        $this->db->update('sesiones', $session_down);
        return;
    }

    function verificar_sesion($username) {
        $this->db->where('username', $username);
        $query = $this->db->get('sesiones');
        if ($query->row('identificador') == 1) {
            return true;
        } else {
            return false;
        }
    }

    function obtener_nombre_usuario($username) {
        $this->db->select('nombre');
        $this->db->from('usuarios');
        $this->db->where('username', $username);
        $query = $this->db->get();
        return $query->row('nombre');
    }

    function obtener_codigo_unico($username) {
        $this->db->select('codigo_unico');
        $this->db->from('usuarios');
        $this->db->where('username', $username);
        $query = $this->db->get();
        return $query->row('codigo_unico');
    }

}
