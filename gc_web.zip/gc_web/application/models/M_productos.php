<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_productos extends CI_Model { /* NUEVO MODELO (HEREDA DE LAS CARACTERISTICAS GENERALES DE LOS MODELOS) */

    function __construct() { /* CONSTRUCTOR POR DEFECTO, SIEMPRE DEBE CREARSE */
        parent::__construct();
        $this->load->database(); /* INDICO QUE VOY A USAR LA FUNCION DE BASES DE DATOS QUE HEREDA DE LAS CARACTERISTICAS GENERALES
          DE LOS MODELOS */
    }

    function contar_existencias($id_producto) {
        $this->db->select('p.id_producto, p.nombre as Nom, p.id_marca, p.codigo as Cod, p.precio as Prec, p.minimo as Min');
        $this->db->from('productos p');
        $this->db->where('id_producto', $id_producto);
        $query = $this->db->get();
        return $query->result();
    }

    function agregar_producto($data) {
        $this->db->insert('productos', $data);
        return;
    }

    function buscar_todos() {
        $this->db->select('p.id_producto, p.nombre as Nom, p.codigo as Cod, p.precio as Prec, p.cantidad as Can, p.minimo as Min');
        $this->db->from('productos p');
        $this->db->where('codigo_unico', $this->session->userdata('codigo_unico'));
        $this->db->order_by("Nom", "asc");
        $query = $this->db->get();
        return $query->result();
    }

    function agregar_existencia($id_producto) {
        $data_editar = $this->input->post();
        unset($data_editar['btn']);
        $anterior = $this->buscar_por_id($id_producto);
        foreach ($anterior as $ca) {
            $cantidad_anterior = $ca->Cant;
            $id = $ca->id_producto;
        }
        $data_editar ['cantidad'] = $data_editar ['cantidad'] + $cantidad_anterior;
        $this->db->where('id_producto', $id);
        $this->db->where('codigo_unico', $this->session->userdata('codigo_unico'));
        $this->db->update('productos', $data_editar);
        return;
    }

    function descontar_existencia($data) {
        foreach ($data as $cant) {
            $cantidad_a_descontar = $cant->cantidad;
            $id = $cant->id_producto;
        }
        $cant_prod = $this->buscar_por_id($id);
        foreach ($cant_prod as $cant) {
            $cantidad_anterior = $cant->Cant;
        }
        $data_editar ['cantidad'] = $cantidad_anterior - $cantidad_a_descontar;
        $this->db->where('id_producto', $id);
        $this->db->where('codigo_unico', $this->session->userdata('codigo_unico'));
        $this->db->update('productos', $data_editar);
        return;
    }

    function buscar_por_id($id_producto) {
        $this->db->select('p.id_producto, p.id_usuario, p.cantidad as Cant, p.nombre as Nom, p.minimo as Min, '
                . 'p.codigo as Cod, p.precio as Prec, p.codigo_unico');
        $this->db->from('productos p');
        $this->db->where('p.id_producto', $id_producto);
        $this->db->where('p.codigo_unico', $this->session->userdata('codigo_unico'));
        $query = $this->db->get();
        return $query->result();
    }

    function editar($id_producto,$data_editar) {
        unset($data_editar['btn']);
        $this->db->where('id_producto', $id_producto);
        $this->db->where('codigo_unico', $this->session->userdata('codigo_unico'));
        $this->db->update('productos', $data_editar);
        return;
    }

}
