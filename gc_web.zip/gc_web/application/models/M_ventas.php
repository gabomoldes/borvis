<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class M_ventas extends CI_Model { /* NUEVO MODELO (HEREDA DE LAS CARACTERISTICAS GENERALES DE LOS MODELOS) */

    function __construct() { /* CONSTRUCTOR POR DEFECTO, SIEMPRE DEBE CREARSE */
        parent::__construct();
        $this->load->database(); /* INDICO QUE VOY A USAR LA FUNCION DE BASES DE DATOS QUE HEREDA DE LAS CARACTERISTICAS GENERALES
          DE LOS MODELOS */
    }

    function select_forma_pago() {
        $this->db->select('id_forma_pago, desc');
        $this->db->from('forma_pago');
        $this->db->order_by("id_forma_pago", "asc");
        $query = $this->db->get();
        return $query->result();
    }

    function reset_temp_1($codigo_unico) {
        $this->db->where('codigo_unico', $codigo_unico);
        return $this->db->delete('temp_1');
    }

    function vender_paso1($data) {
        unset($data['btn']);
        $this->db->insert('temp_1', $data);
        return;
    }

    function vender_pasos_siguientes() {
        $data_editar = $this->input->post();
        unset($data_editar['btn']);
        $this->db->where('codigo_unico', $this->session->userdata('codigo_unico'));
        $this->db->update('temp_1', $data_editar);
        return;
    }

    function recuperar_temp1($codigo_unico) {
        $this->db->select('t.id_temp_1, t.codigo_unico, t.id_producto, t.codigo as Cod, t.id_usuario, t.precio as Prec, t.recargo, t.descuento,'
                . 't.monto_final, t.cantidad as Cant, t.cuotas, t.id_forma_pago, fp.id_forma_pago, fp.desc as Fp, p.id_producto, p.nombre as Nom,'
                . 't.ult_digitos, t.cod_aut');
        $this->db->from('temp_1 t');
        $this->db->join('forma_pago fp', 't.id_forma_pago = fp.id_forma_pago');
        $this->db->join('productos p', 't.id_producto = p.id_producto');
        $this->db->where('t.codigo_unico', $codigo_unico);
        $query = $this->db->get();
        return $query->result();
    }

    function recuperar_datos() {
        $this->db->select('t.codigo_unico, t.id_producto, t.codigo, t.id_usuario, t.precio, t.recargo, t.descuento,'
                . 't.monto_final, t.cantidad, t.cuotas, t.id_forma_pago,'
                . 't.ult_digitos, t.cod_aut');
        $this->db->from('temp_1 t');
        $this->db->where('codigo_unico', $this->session->userdata('codigo_unico'));
        $query = $this->db->get();
        return $query->result();
    }

    function grabar_venta($data) {
        foreach ($data as $venta) {
            $venta = array(
                'codigo_unico' => $venta->codigo_unico,
                'id_producto' => $venta->id_producto,
                'codigo' => $venta->codigo,
                'id_usuario' => $venta->id_usuario,
                'precio' => $venta->precio,
                'recargo' => $venta->recargo,
                'descuento' => $venta->descuento,
                'monto_final' => $venta->monto_final,
                'cantidad' => $venta->cantidad,
                'cuotas' => $venta->cuotas,
                'id_forma_pago' => $venta->id_forma_pago,
                'ult_digitos' => $venta->ult_digitos,
                'cod_aut' => $venta->cod_aut,
            );
        }
        $this->db->insert('ventas', $venta);
        return;
    }

    function buscar_todas() {
        $this->db->select('v.id_venta, v.codigo_unico, v.id_producto, v.codigo as Cod, v.id_usuario, v.precio as Prec, v.recargo, v.descuento,'
                . 'v.monto_final, v.cantidad as Cant, v.cuotas, v.id_forma_pago, fp.id_forma_pago, fp.desc as Fp, p.id_producto, p.nombre as Nom,'
                . 'v.ult_digitos, v.cod_aut, v.fecha');
        $this->db->from('ventas v');
        $this->db->join('forma_pago fp', 'v.id_forma_pago = fp.id_forma_pago');
        $this->db->join('productos p', 'v.id_producto = p.id_producto');
        $this->db->where('v.codigo_unico', $this->session->userdata('codigo_unico'));
        $this->db->order_by("fecha", "desc");
        $query = $this->db->get();
        return $query->result();
    }

}
