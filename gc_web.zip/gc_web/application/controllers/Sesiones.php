<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Sesiones extends CI_Controller { /* NUEVO CONTROLADOR (HEREDA DE LAS CARACTERISTICAS GENERALES DE LOS CONTROLADORES) */

    function __construct() { /* CONSTRUCTOR POR DEFECTO, SIEMPRE DEBE CREARSE */
        parent::__construct();
        $this->load->model('M_usuarios');
        $this->load->model('M_ventas');
    }

    function index() {
        if ($this->session->userdata('username')) {
            redirect('principal');
        }
        if ($this->input->post('password')) {
            if ($this->form_validation->run('login') == TRUE) {
                if ($this->M_usuarios->login($this->input->post('username'), ($this->input->post('password')))) {
                    $datos_sesion = array(
                        'username' => $this->input->post('username'),
                        'nombre' => $this->M_usuarios->obtener_nombre_usuario($this->input->post('username')),
                        'codigo_unico' => $this->M_usuarios->obtener_codigo_unico($this->input->post('username')),
                    );
                    $this->session->set_userdata($datos_sesion);
                    redirect('principal');
                }
            } else {
                $this->load->view('v_login');
            }
        } else {
            $this->load->view('v_login');
        }
    }

    function logout() {
        $this->M_ventas->reset_temp_1($this->session->userdata('codigo_unico'));
        $this->session->sess_destroy();
        $this->M_usuarios->baja_sesion(($this->session->userdata('username')));
        redirect('sesiones');
    }

    function ver() {
        echo ('<br>');
        print_r($this->session->userdata('username'));
        echo ('<br>');
        print_r($this->session->userdata('nombre'));
        echo ('<br>');
        print_r($this->session->userdata('codigo_unico'));
        echo ('<br>');
    }

}
