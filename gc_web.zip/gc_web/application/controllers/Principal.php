<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Principal extends CI_Controller {

    function __construct() { /* CONSTRUCTOR POR DEFECTO */
        parent::__construct();
        $this->load->model('M_productos');
        $this->load->model('M_usuarios');
    }

    public function index() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $this->load->view('header');
            $this->load->view('v_principal');
        } else {
            redirect(Sesiones);
        }
    }

}
