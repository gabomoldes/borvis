<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Producto extends CI_Controller {

    function __construct() { /* CONSTRUCTOR POR DEFECTO */
        parent::__construct();
        $this->load->model('M_productos');
        $this->load->model('M_usuarios');
    }

    public function index() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $data ['producto'] = $this->M_productos->buscar_todos();
            $this->load->view('header');
            $this->load->view('v_productos', $data);
        } else {
            redirect(Sesiones);
        }
    }

    function nuevo_producto() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            if ($this->input->post()) {
                if ($this->form_validation->run('productos') == TRUE) {
                    $carga = $this->input->post();
                    unset($carga['btn']);
                    $carga['codigo_unico'] = $this->session->userdata('codigo_unico');
                    $this->M_productos->agregar_producto($carga);
                    $this->index();
                } else {
                    $this->load->view('header');
                    $this->load->view('v_nuevo_producto');
                }
            } else {
                $this->load->view('header');
                $this->load->view('v_nuevo_producto');
            }
        } else {
            redirect(Sesiones);
        }
    }

    function editar($id_producto) {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            if ($this->input->post()) {
                if ($this->form_validation->run('editar') == TRUE) {
                    $data_editar = $this->input->post();
                    $this->M_productos->editar($id_producto, $data_editar);
                    $this->index();
                } else {
                    $datos['datos'] = $this->M_productos->buscar_por_id($id_producto);
                    $this->load->view('header');
                    $this->load->view('v_editar', $datos);
                }
            } else {
                $datos['datos'] = $this->M_productos->buscar_por_id($id_producto);
                $this->load->view('header');
                $this->load->view('v_editar', $datos);
            }
        } else {
            redirect(Sesiones);
        }
    }

    function agregar_existencia($id_producto) {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            if ($this->input->post()) {
                if ($this->form_validation->run('agregar_existencia') == TRUE) {
                    $this->M_productos->agregar_existencia($id_producto);
                    $this->index();
                } else {
                    $datos['producto'] = $this->M_productos->buscar_por_id($id_producto);
                    $this->load->view('header');
                    $this->load->view('v_agregar_existencia', $datos);
                }
            } else {
                $datos['producto'] = $this->M_productos->buscar_por_id($id_producto);
                $this->load->view('header');
                $this->load->view('v_agregar_existencia', $datos);
            }
        } else {
            redirect(Sesiones);
        }
    }

}
