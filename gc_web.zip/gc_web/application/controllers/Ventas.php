<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ventas extends CI_Controller {

    function __construct() { /* CONSTRUCTOR POR DEFECTO */
        parent::__construct();
        $this->load->model('M_productos');
        $this->load->model('M_ventas');
        $this->load->model('M_usuarios');
    }

    public function index() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $data['data'] = $this->M_existencias->buscar_todos();
            $this->load->view('v_principal', $data);
        } else {
            redirect(Sesiones);
        }
    }

    public function vender_paso1($id_producto) {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            if ($this->input->post()) {
                $data = $this->input->post();
                $this->M_ventas->vender_paso1($data);
                redirect('ventas/vender_paso2');
            } else {
                $this->M_ventas->reset_temp_1($this->session->userdata('codigo_unico'));
                $datos['producto'] = $this->M_productos->buscar_por_id($id_producto);
                $datos['forma_pago'] = $this->M_ventas->select_forma_pago();
                $this->load->view('header');
                $this->load->view('v_venta', $datos);
            }
        } else {
            redirect(Sesiones);
        }
    }

    public function vender_paso2() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            if ($this->input->post()) {
                if ($this->form_validation->run('paso2_venta') == TRUE) {
                    $datos['producto'] = $this->M_ventas->recuperar_temp1($this->session->userdata('codigo_unico'));
                    foreach ($datos['producto'] as $dt) {
                        if ($dt->id_forma_pago == 1) {
                            $this->M_ventas->vender_pasos_siguientes($datos);
                            redirect('ventas/vender_paso3_efe');
                        }
                    }
                    foreach ($datos['producto'] as $dt) {
                        if ($dt->id_forma_pago == 2) {
                            $this->M_ventas->vender_pasos_siguientes($datos);
                            redirect('ventas/vender_paso3_tc');
                        }
                    }
                    foreach ($datos['producto'] as $dt) {
                        if ($dt->id_forma_pago == 3) {
                            $this->M_ventas->vender_pasos_siguientes($datos);
                            redirect('ventas/vender_paso3_td');
                        }
                    }
                } else {
                    $datos['producto'] = $this->M_ventas->recuperar_temp1($this->session->userdata('codigo_unico'));
                    foreach ($datos['producto'] as $dt) {
                        if ($dt->id_forma_pago == 1) {
                            $this->load->view('header');
                            $this->load->view('v_venta2_efe', $datos);
                        }
                    }
                    foreach ($datos['producto'] as $dt) {
                        if ($dt->id_forma_pago == 2) {
                            $this->load->view('header');
                            $this->load->view('v_venta2_tc', $datos);
                        }
                    }
                    foreach ($datos['producto'] as $dt) {
                        if ($dt->id_forma_pago == 3) {
                            $this->load->view('header');
                            $this->load->view('v_venta2_td', $datos);
                        }
                    }
                }
            } else {
                $datos['producto'] = $this->M_ventas->recuperar_temp1($this->session->userdata('codigo_unico'));
                foreach ($datos['producto'] as $dt) {
                    if ($dt->id_forma_pago == 1) {
                        $this->load->view('header');
                        $this->load->view('v_venta2_efe', $datos);
                    }
                }
                foreach ($datos['producto'] as $dt) {
                    if ($dt->id_forma_pago == 2) {
                        $this->load->view('header');
                        $this->load->view('v_venta2_tc', $datos);
                    }
                }
                foreach ($datos['producto'] as $dt) {
                    if ($dt->id_forma_pago == 3) {
                        $this->load->view('header');
                        $this->load->view('v_venta2_td', $datos);
                    }
                }
            }
        } else {
            redirect(Sesiones);
        }
    }

    public function vender_paso3_efe() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $datos['producto'] = $this->M_ventas->recuperar_temp1($this->session->userdata('codigo_unico'));
            if ($this->input->post()) {
                $this->M_ventas->vender_pasos_siguientes($datos);
                redirect('ventas/vender_result_efe');
            } else {
                $this->load->view('header');
                $this->load->view('v_venta3_efe', $datos);
            }
        } else {
            redirect(Sesiones);
        }
    }

    public function vender_result_efe() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $datos['producto'] = $this->M_ventas->recuperar_temp1($this->session->userdata('codigo_unico'));
            $venta = $this->M_ventas->recuperar_datos();
            if ($venta == !null) {
                $this->M_ventas->grabar_venta($venta);
                $this->M_productos->descontar_existencia($venta);
                $this->M_ventas->reset_temp_1($this->session->userdata('codigo_unico'));
                $this->load->view('header');
                $this->load->view('v_venta_exito_efe', $datos);
            } else {
                $this->load->view('header');
                $this->load->view('v_error_temp_vacio');
            }
        } else {
            redirect(Sesiones);
        }
    }

    public function vender_paso3_tc() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $datos['producto'] = $this->M_ventas->recuperar_temp1($this->session->userdata('codigo_unico'));
            if ($this->input->post()) {
                $this->M_ventas->vender_pasos_siguientes($datos);
                redirect('ventas/vender_paso4_tc');
            } else {
                $this->load->view('header');
                $this->load->view('v_venta3_tc', $datos);
            }
        } else {
            redirect(Sesiones);
        }
    }

    public function vender_paso4_tc() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $datos['producto'] = $this->M_ventas->recuperar_temp1($this->session->userdata('codigo_unico'));
            if ($this->input->post()) {
                if ($this->form_validation->run('paso4_venta') == TRUE) {
                    $this->M_ventas->vender_pasos_siguientes($datos);
                    redirect('ventas/vender_result_tc');
                } else {
                    $this->load->view('header');
                    $this->load->view('v_venta4_tc', $datos);
                }
            } else {
                $this->load->view('header');
                $this->load->view('v_venta4_tc', $datos);
            }
        } else {
            redirect(Sesiones);
        }
    }

    public function vender_result_tc() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $datos['producto'] = $this->M_ventas->recuperar_temp1($this->session->userdata('codigo_unico'));
            $venta = $this->M_ventas->recuperar_datos();
            if ($venta == !null) {
                $this->M_ventas->grabar_venta($venta);
                $this->M_productos->descontar_existencia($venta);
                $this->M_ventas->reset_temp_1($this->session->userdata('codigo_unico'));
                $this->load->view('header');
                $this->load->view('v_venta_exito_tc', $datos);
            } else {
                $this->load->view('header');
                $this->load->view('v_error_temp_vacio');
            }
        } else {
            redirect(Sesiones);
        }
    }

    public function vender_paso3_td() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $datos['producto'] = $this->M_ventas->recuperar_temp1($this->session->userdata('codigo_unico'));
            if ($this->input->post()) {
                $this->M_ventas->vender_pasos_siguientes($datos);
                redirect('ventas/vender_paso4_td');
            } else {
                $this->load->view('header');
                $this->load->view('v_venta3_td', $datos);
            }
        } else {
            redirect(Sesiones);
        }
    }

    public function vender_paso4_td() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $datos['producto'] = $this->M_ventas->recuperar_temp1($this->session->userdata('codigo_unico'));
            if ($this->input->post()) {
                if ($this->form_validation->run('paso4_venta') == TRUE) {
                    $this->M_ventas->vender_pasos_siguientes($datos);
                    redirect('ventas/vender_result_td');
                } else {
                    $this->load->view('header');
                    $this->load->view('v_venta4_td', $datos);
                }
            } else {
                $this->load->view('header');
                $this->load->view('v_venta4_td', $datos);
            }
        } else {
            redirect(Sesiones);
        }
    }

    public function vender_result_td() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $datos['producto'] = $this->M_ventas->recuperar_temp1($this->session->userdata('codigo_unico'));
            $venta = $this->M_ventas->recuperar_datos();
            if ($venta == !null) {
                $this->M_ventas->grabar_venta($venta);
                $this->M_productos->descontar_existencia($venta);
                $this->M_ventas->reset_temp_1($this->session->userdata('codigo_unico'));
                $this->load->view('header');
                $this->load->view('v_venta_exito_td', $datos);
            } else {
                $this->load->view('header');
                $this->load->view('v_error_temp_vacio');
            }
        } else {
            redirect(Sesiones);
        }
    }

    public function mostrar_ventas() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $data ['listado'] = $this->M_ventas->buscar_todas();
            $this->load->view('header');
            $this->load->view('v_todas_ventas', $data);
        } else {
            redirect(Sesiones);
        }
    }

    public function grap() {
        if ($this->M_usuarios->verificar_sesion($this->session->userdata('username'))) {
            $this->load->view('header');
            $this->load->view('v_ventas_graficas');
        } else {
            redirect(Sesiones);
        }
    }

}
