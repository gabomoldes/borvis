<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$config = array(
    'productos' => array(
        array(
            'field' => "nombre",
            'label' => 'Nombre',
            'rules' => 'required|alpha_numeric_spaces|min_length[2]|max_length[100]'),
        array(
            'field' => "codigo",
            'label' => 'Codigo',
            'rules' => 'required|alpha_numeric|max_length[100]'),
        array(
            'field' => "precio",
            'label' => 'Precio',
            'rules' => 'required|numeric|max_length[9]'),
        array(
            'field' => "cantidad",
            'label' => 'Cantidad',
            'rules' => 'required|integer|max_length[9]'),
        array(
            'field' => "minimo",
            'label' => 'Minimo',
            'rules' => 'required|integer|max_length[9]')
    ),
    'editar' => array(
        array(
            'field' => "nombre",
            'label' => 'Nombre',
            'rules' => 'required|alpha_numeric_spaces|min_length[2]|max_length[100]'),
        array(
            'field' => "codigo",
            'label' => 'Codigo',
            'rules' => 'required|alpha_numeric|max_length[100]'),
        array(
            'field' => "precio",
            'label' => 'Precio',
            'rules' => 'required|numeric|max_length[9]'),
        array(
            'field' => "minimo",
            'label' => 'Minimo',
            'rules' => 'required|integer|max_length[9]')
    ),
    'agregar_existencia' => array(
        array(
            'field' => "cantidad",
            'label' => 'a actualizar',
            'rules' => 'required|integer|max_length[9]')
    ),
    'login' => array(
        array(
            'field' => "username",
            'label' => 'Usuario',
            'rules' => 'required|alpha_numeric|min_length[5]'),
        array(
            'field' => "password",
            'label' => 'Contraseña',
            'rules' => 'required|alpha_numeric|min_length[9]'),
    ),
    'paso2_venta' => array(
        array(
            'field' => "recargo",
            'label' => 'Recargo',
            'rules' => 'integer|max_length[3]|less_than[101]|greater_than[-1]'),
        array(
            'field' => "descuento",
            'label' => 'Descuento',
            'rules' => 'integer|max_length[3]|less_than[101]|greater_than[-1]'),
    ),
    'paso4_venta' => array(
        array(
            'field' => "ult_digitos",
            'label' => 'Ultimos 4 digitos',
            'rules' => 'required|integer|exact_length[4]|'),
        array(
            'field' => "cod_aut",
            'label' => 'Codigo de autorizacion',
            'rules' => 'required|integer|exact_length[6]|'),
    ),
);
