<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <center><b><h4>¡hoy!</h4></b></center>
                    </div>
                    <div class="panel-body">
                        Hoy
                        <hr>
                        <p class = "text-center">
                            <a href='<?php echo base_url() ?>index.php/ventas/mostrar_ventas' class="btn btn-success">Ver Historial de ventas</a>
                            <a href='<?php echo base_url() ?>index.php/producto' class="btn btn-info">Volver a Listado</a>
                        </p>
                    </div>
                    <!--/.panel-body -->
                </div>
            </div>
            <!-- /.col-lg-12 -->
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
</div>
</div>


<!-- jQuery -->
<script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url() ?>vendor/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>dist/js/sb-admin-2.js"></script>

</body>

</html>