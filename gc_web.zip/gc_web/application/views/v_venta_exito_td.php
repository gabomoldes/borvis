<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <center><b><h4>¡Venta grabada correctamente!</h4></b></center>
                    </div>
                    <div class="panel-body">
                        <div class="progress progress-striped active">
                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
                                <span class="sr-only">100%</span>
                            </div>
                        </div>
                        <?php foreach ($producto as $lis) { ?>
                            <div class="panel-body">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <?php
                                            echo '<b>Forma de Pago: </b>' . $lis->Fp;
                                            ?>
                                            <br>
                                            <?php echo '<b>Pagos: </b> 1' ?>
                                        </div>
                                        <!--/.col-lg-6 (nested) -->
                                        <div class="col-lg-6">
                                            <?php
                                            echo '<b>Ultimos 4 digitos: </b>' . $lis->ult_digitos;
                                            ?>
                                            <br>
                                            <?php
                                            echo '<b>Codigo de Autorizacion: </b>' . $lis->cod_aut;
                                            ?>
                                        </div>
                                        <!--/.col-lg-6 (nested) -->
                                    </div>
                                    <!-- /.row -->              
                                </div>
                                <div class="table">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Codigo</th>
                                                <th>Concepto</th>
                                                <th>Cantidad</th>
                                                <th>Recargo</th>
                                                <th>Descuento</th>
                                                <th>Total</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><?php echo $lis->Cod ?></td>
                                                <td><?php echo $lis->Nom ?></td>
                                                <td><?php echo $lis->Cant ?></td>
                                                <td></td>
                                                <td></td>
                                                <td><?php echo '$' . $Sub = number_format($lis->Prec * $lis->Cant, 2, '.', '') ?></td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td><?php echo '(' . $lis->recargo . '%' . ')' ?></td>
                                                <td></td>
                                                <td>
                                                    <?php
                                                    if ($lis->recargo > 0) {
                                                        $recargo = ($lis->Prec * $lis->recargo / 100) * $lis->Cant;
                                                        echo '$' . $Rec = number_format($recargo, 2, '.', '');
                                                    } else {
                                                        $recargo = 0;
                                                        echo '$' . $Rec = number_format($recargo, 2, '.', '');
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td><?php echo '(' . $lis->descuento . '%' . ')' ?></td>
                                                <td>
                                                    <?php
                                                    if ($lis->descuento > 0) {
                                                        $descuento = ($lis->Prec * $lis->descuento / 100) * $lis->Cant;
                                                        echo '$' . $Desc = number_format($descuento, 2, '.', '');
                                                    } else {
                                                        $descuento = 0;
                                                        echo '$' . $Desc = number_format($descuento, 2, '.', '');
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td>
                                                    <?php
                                                    if ($lis->recargo > 0) {
                                                        $recargo = $lis->Prec * $lis->recargo / 100;
                                                    } else {
                                                        $recargo = 0;
                                                    }
                                                    if ($lis->descuento > 0) {
                                                        $descuento = $lis->Prec * $lis->descuento / 100;
                                                    } else {
                                                        $descuento = 0;
                                                    }
                                                    echo '$' . $Total = number_format(($lis->Prec + $recargo - $descuento) * $lis->Cant, 2, '.', '');
                                                    ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <hr>   
                            <?php } ?>
                            <p class = "text-center">
                                <a href='<?php echo base_url() ?>index.php/ventas/mostrar_ventas' class="btn btn-success">Ver Historial de ventas</a>
                                <a href='<?php echo base_url() ?>index.php/producto' class="btn btn-info">Volver a Listado</a>
                            </p>
                        </div>
                        <!--/.panel-body -->
                    </div>
                </div>
                <!-- /.col-lg-12 -->
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
</div>
</div>


<!-- jQuery -->
<script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url() ?>vendor/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>dist/js/sb-admin-2.js"></script>

</body>

</html>