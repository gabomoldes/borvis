<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <center><b><h4>Venta: Paso 2</h4></b></center>
                    </div>
                    <div class="panel-body">
                        <div class="progress progress-striped active">
                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 33%">
                                <span class="sr-only">33%</span>
                            </div>
                        </div>
                        Informacion de la compra:<br>
                        <hr>
                        <?php echo form_open() ?>
                        <?php foreach ($producto as $lis) { ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <p class="fa fa-pencil"></p><b> Producto: </b> <?php echo $lis->Nom ?><br>
                                    <p class="fa fa-barcode"></p><b> Codigo: </b><?php echo $lis->Cod ?><br>
                                    <p class="fa fa-dollar"></p><b> Precio: </b><?php echo '$' . $Prec = number_format($lis->Prec, 2, '.', '') ?><br>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                                <div class = "col-lg-6">
                                    <p class="fa fa-shopping-cart"></p><b> Cantidad a comprar: </b><?php echo $lis->Cant ?><br>
                                    <p class="fa fa-credit-card"></p><b> Forma de Pago: </b><?php echo $lis->Fp ?><br>
                                    <p class="fa fa-dollar"></p><b> Subtotal: </b><?php echo '$' . $Sub = number_format($lis->Prec * $lis->Cant, 2, '.', '') ?><br>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                            </div>
                            <hr>
                            Recargos y Descuentos:
                            <div class="row">
                                <div class="col-lg-6">
                                    <p class="fa fa-plus-circle"></p><b> Recargo: </b>
                                    <?php
                                    $recargo = array(
                                        'name' => 'recargo',
                                        'id' => 'recargo',
                                        'placeholder' => 'Porcentaje a recargar',
                                        'value' => set_value(0),
                                    );
                                    ?>
                                        <?php echo form_input($recargo) ?><br>
                                        <?php echo form_error('recargo') ?>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                                <div class = "col-lg-6">
                                    <p class="fa fa-minus-circle"></p><b> Descuento: </b>
                                    <?php
                                    $descuento = array(
                                        'name' => 'descuento',
                                        'id' => 'descuento',
                                        'placeholder' => 'Porcentaje a descontar',
                                        'value' => set_value(0),
                                    );
                                    ?>
                                        <?php echo form_input($descuento) ?><br>
                                        <?php echo form_error('descuento') ?>
                                </div>
                                <?php
                                echo form_hidden('codigo_unico', $lis->codigo_unico);
                                echo form_hidden('codigo', $lis->Cod);
                                echo form_hidden('id_producto', $lis->id_producto);
                                echo form_hidden('id_usuario', $lis->id_usuario);
                                echo form_hidden('precio', $Prec);
                                ?>
                            <?php } ?>
                            <!--/.col-lg-6 (nested) -->
                        </div>
                        <hr>
                        <p class="text-center">
                            <input type="button" class = "btn btn-info" value="Volver" name="volver" onclick="history.back()" />
                            <?php echo form_submit('btn', 'Siguiente', 'class = "btn btn-success"') ?>
                        </p>
                        <?php echo form_close() ?>
                        <p class = "text-right">
                            <a href='<?php echo base_url() ?>index.php/producto' class="btn btn-danger">Cancelar</a>
                        </p>
                    </div>
                    <!--/.panel-body -->
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<!-- jQuery -->
<script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url() ?>vendor/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>dist/js/sb-admin-2.js"></script>

</body>

</html>