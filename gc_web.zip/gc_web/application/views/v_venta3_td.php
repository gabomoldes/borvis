<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <center><b><h4>Venta: Paso 3</h4></b></center>
                    </div>
                    <div class="panel-body">
                        <div class="progress progress-striped active">
                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
                                <span class="sr-only">50%</span>
                            </div>
                        </div>
                        Informacion de la compra:<br>
                        <hr>
                        <?php echo form_open() ?>
                        <?php foreach ($producto as $lis) { ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <p class="fa fa-pencil"></p><b> Producto: </b> <?php echo $lis->Nom ?><br>
                                    <p class="fa fa-barcode"></p><b> Codigo: </b><?php echo $lis->Cod ?><br>
                                    <p class="fa fa-dollar"></p><b> Precio: </b><?php echo '$' . $Prec = number_format($lis->Prec, 2, '.', '') ?><br>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                                <div class = "col-lg-6">
                                    <p class="fa fa-shopping-cart"></p><b> Cantidad a comprar: </b><?php echo $lis->Cant ?><br>
                                    <p class="fa fa-credit-card"></p><b> Forma de Pago: </b><?php echo $lis->Fp ?><br>
                                    <p class="fa fa-dollar"></p><b> Subtotal: </b><?php echo '$' . $Sub = number_format($lis->Prec * $lis->Cant, 2, '.', '') ?><br>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                            </div>
                            <hr>
                            Aplicacion de recargos y descuentos:
                            <div class="row">
                                <div class="col-lg-6">
                                    <p class="fa fa-plus-circle"></p><b> Recargo: </b><?php echo $lis->recargo . '%' ?><br>
                                    <p class="fa fa-minus-circle"></p><b> Descuento: </b><?php echo $lis->descuento . '%' ?><br>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                                <div class = "col-lg-6">
                                    <p class="fa fa-plus-circle"></p><b> Monto recargo: </b>
                                    <?php
                                    if ($lis->recargo > 0) {
                                        $recargo = ($lis->Prec * $lis->recargo / 100) * $lis->Cant;
                                        echo '$' . $Rec = number_format($recargo, 2, '.', '');
                                    } else {
                                        $recargo = 0;
                                        echo '$' . $Rec = number_format($recargo, 2, '.', '');
                                    }
                                    ?><br>
                                    <p class="fa fa-minus-circle"></p><b> Monto de descuento: </b>
                                    <?php
                                    if ($lis->descuento > 0) {
                                        $descuento = ($lis->Prec * $lis->descuento / 100) * $lis->Cant;
                                        echo '$' . $Desc = number_format($descuento, 2, '.', '');
                                    } else {
                                        $descuento = 0;
                                        echo '$' . $Desc = number_format($descuento, 2, '.', '');
                                    }
                                    ?>
                                    <br>
                                    <p class="fa fa-dollar"></p><b> A cobrar con <?php echo $lis->Fp ?>: </b>
                                    <?php
                                    if ($lis->recargo > 0) {
                                        $recargo = $lis->Prec * $lis->recargo / 100;
                                    } else {
                                        $recargo = 0;
                                    }
                                    if ($lis->descuento > 0) {
                                        $descuento = $lis->Prec * $lis->descuento / 100;
                                    } else {
                                        $descuento = 0;
                                    }
                                    echo '$' . $Total = number_format(($lis->Prec + $recargo - $descuento) * $lis->Cant, 2, '.', '');
                                    ?><br>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                            </div>
                            <?php
                            echo form_hidden('codigo_unico', $lis->codigo_unico);
                            echo form_hidden('codigo', $lis->Cod);
                            echo form_hidden('id_producto', $lis->id_producto);
                            echo form_hidden('id_usuario', $lis->id_usuario);
                            echo form_hidden('precio', $lis->Prec);
                            echo form_hidden('monto_final', ($lis->Prec + $recargo - $descuento) * $lis->Cant);
                            ?>
                        <?php } ?>
                        <hr>
                        <p class="text-center">
                            <input type="button" class = "btn btn-info" value="Volver" name="volver" onclick="history.back()" />
                            <?php echo form_submit('btn', 'Siguiente', 'class = "btn btn-success"') ?>
                        </p>
                        <?php echo form_close() ?>
                        <p class = "text-right">
                            <a href='<?php echo base_url() ?>index.php/producto' class="btn btn-danger">Cancelar</a>
                        </p>
                    </div>
                    <!--/.panel-body -->
                </div>
            </div>
            <!-- /.col-lg-12 -->
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<!-- jQuery -->
<script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url() ?>vendor/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>dist/js/sb-admin-2.js"></script>

</body>

</html>