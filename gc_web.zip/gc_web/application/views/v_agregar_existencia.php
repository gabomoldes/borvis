<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <center><b><h4>Agregar Stock</h4></b></center>
                    </div>
                    <div class="panel-body">
                        <?php echo form_open() ?>
                        <?php foreach ($producto as $lis) { ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <p class="fa fa-pencil"></p><b> Nombre: </b> <?php echo $lis->Nom ?><br>
                                    <p class="fa fa-barcode"></p><b> Codigo: </b><?php echo $lis->Cod ?><br>
                                    <p class="fa fa-dollar"></p><b> Precio: </b><?php echo '$' . $lis->Prec ?><br>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                                <div class = "col-lg-6">
                                    <p class="fa fa-cubes"></p><b> Cantidad Actual: </b><?php echo $lis->Cant ?><br>
                                    <p class="fa fa-warning"></p><b> Stock Mimino: </b><?php echo $lis->Min ?><br>
                                    <?php
                                    $cantidad = array(
                                        'name' => 'cantidad',
                                        'id' => 'cantidad',
                                        'size' => '4',
                                        'placeholder' => 'cantidad',
                                        'value' => set_value('cantidad'),
                                    );
                                    ?>
                                    <p class="fa fa-plus-circle"></p><b> Agregar: <?php echo form_input($cantidad) ?> unidades.</b>
                                    <?php echo form_error('cantidad') ?>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                            </div>
                            <hr>
                            <center><?php echo form_submit('btn', 'Agregar Stock', 'class = "btn btn-success"') ?></center>
                            
                        <?php } ?>
                        <?php echo form_close() ?>

                        <p class = "text-right">
                            <a href='<?php echo base_url() ?>index.php/producto' class="btn btn-danger">Cancelar</a>
                        </p>


                    </div>
                    <!--/.panel-body -->
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<!-- jQuery -->
<script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url() ?>vendor/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>dist/js/sb-admin-2.js"></script>

</body>

</html>