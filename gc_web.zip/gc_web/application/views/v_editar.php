<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <center><b><h4>Editar Producto</h4></b></center>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <?php echo form_open() ?>
                                <div class="form-group" input-group>
                                    <p class="fa fa-pencil"></p> <label>Modelo/Nombre del producto</label>
                                    <?php
                                    $nombre = array(
                                        'name' => 'nombre',
                                        'id' => 'nombre',
                                        'placeholder' => 'Ingrese el Nombre/Modelo del producto',
                                        'value' => set_value('nombre', $datos[0]->Nom),
                                        'class' => 'form-control',
                                    );
                                    ?>
                                    <?php echo form_input($nombre) ?>
                                    <?php echo form_error('nombre') ?>
                                </div>
                                <div class="form-group" input-group>
                                    <p class="fa fa-barcode"></p> <label>Codigo</label>
                                    <?php
                                    $codigo = array(
                                        'name' => 'codigo',
                                        'id' => 'codigo',
                                        'placeholder' => 'Ingrese el codigo del producto',
                                        'value' => set_value('codigo', $datos[0]->Cod),
                                        'class' => 'form-control',
                                    );
                                    ?>
                                    <?php echo form_input($codigo) ?>
                                    <?php echo form_error('codigo') ?>   
                                </div>
                            </div>
                            <!--/.col-lg-6 (nested) -->
                            <div class = "col-lg-6">
                                <div class="form-group" input-group>
                                    <p class="fa fa-dollar"></p> <label>Precio</label>
                                    <?php
                                    $precio = array(
                                        'name' => 'precio',
                                        'id' => 'precio',
                                        'placeholder' => 'Ingrese el precio',
                                        'value' => set_value('precio', $datos[0]->Prec),
                                        'class' => 'form-control',
                                    );
                                    ?>
                                    <?php echo form_input($precio) ?>
                                    <?php echo form_error('precio') ?>
                                </div>
                                <div class="form-group" input-group>
                                    <p class="fa fa-warning"></p> <label>Stock Minimo</label>
                                    <?php
                                    $minimo = array(
                                        'name' => 'minimo',
                                        'id' => 'minimo',
                                        'placeholder' => 'Ingrese la cantidad de stock minimo',
                                        'value' => set_value('minimo', $datos[0]->Min),
                                        'class' => 'form-control',
                                    );
                                    ?>
                                    <?php echo form_input($minimo) ?>
                                    <span class="help-block">
                                        Cantidad de stock minimo para que el sistema le brinde un Alerta
                                    </span>
                                    <?php echo form_error('minimo') ?>
                                </div>
                            </div>
                            <!--/.col-lg-6 (nested) -->
                        </div>
                        <p class="text-center">
                            <button type = "reset" class = "btn btn-warning">Reset</button>
                            <?php echo form_submit('btn', 'Cargar', 'class = "btn btn-success"') ?>
                        </p>
                        <?php echo form_close() ?>
                        <!--/.row (nested) -->
                        <p class = "text-right">
                            <a href='<?php echo base_url() ?>index.php/producto' class="btn btn-danger">Cancelar</a>
                        </p>
                    </div>
                    <!--/.panel-body -->
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<!-- jQuery -->
<script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url() ?>vendor/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>dist/js/sb-admin-2.js"></script>

</body>

</html>