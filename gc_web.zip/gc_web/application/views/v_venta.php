<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <center><b><h4>Venta: Paso 1</h4></b></center>
                    </div>
                    <div class="panel-body">
                        <?php echo form_open() ?>
                        <?php foreach ($producto as $lis) { ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <p class="fa fa-pencil"></p><b> Producto: </b> <?php echo $lis->Nom ?><br>
                                    <p class="fa fa-barcode"></p><b> Codigo: </b><?php echo $lis->Cod ?><br>
                                    <p class="fa fa-dollar"></p><b> Precio: </b><?php echo '$' . $Prec = number_format($lis->Prec, 2, '.', '') ?><br>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                                <div class = "col-lg-6">
                                    <p class="fa fa-cubes"></p><b> Stock Disponible: </b><?php echo $lis->Cant ?><br>
                                    <p class="fa fa-shopping-cart"></p><b> Cantidad a Vender: </b>
                                    <select name="cantidad">
                                        <?php
                                        for ($cant = 1; $cant <= $lis->Cant; $cant++) {
                                            echo '<option value="' . $cant . '">' . $cant . '</option>';
                                        }
                                        ?>
                                    </select>
                                    <br>
                                    <p class="fa fa-credit-card"></p><b> Forma de Pago: </b>
                                    <select name="id_forma_pago">
                                        <?php
                                        foreach ($forma_pago as $fp) {
                                            echo '<option value="' . $fp->id_forma_pago . '">' . $fp->desc . '</option>';
                                        }
                                        ?>
                                    </select>
                                    <?php
                                    echo form_hidden('codigo_unico', $lis->codigo_unico);
                                    echo form_hidden('codigo', $lis->Cod);
                                    echo form_hidden('id_producto', $lis->id_producto);
                                    echo form_hidden('id_usuario', $lis->id_usuario);
                                    echo form_hidden('precio', $Prec);
                                    ?>
                                <?php } ?>


                            </div>
                            <!--/.col-lg-6 (nested) -->
                        </div>
                        <hr>
                        <p class="text-center">
                            <input type="button" class = "btn btn-info" value="Volver" name="volver" onclick="history.back()" />
                            <?php echo form_submit('btn', 'Siguiente', 'class = "btn btn-success"') ?>
                        </p>
                        <?php echo form_close() ?>
                        <p class = "text-right">
                            <a href='<?php echo base_url() ?>index.php/producto' class="btn btn-danger">Cancelar</a>
                        </p>
                    </div>
                    <!--/.panel-body -->
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<!-- jQuery -->
<script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url() ?>vendor/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>dist/js/sb-admin-2.js"></script>

</body>

</html>