<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">Listado de todos los productos</h2>
                <div class="panel-body">
                    <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>Codigo</th>
                                <th>Producto</th>
                                <th>Cantidad</th>
                                <th>Estado</th>
                                <th>Precio unitario final</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($producto as $lis) { ?>
                                <tr class="odd gradeX">
                                    <td><?php echo $lis->Cod ?></td>
                                    <td><?php echo $lis->Nom ?></td>
                                    <td><?php
                                        if ($lis->Can <= 0) {
                                            echo '-';
                                        } else {
                                            echo $lis->Can;
                                        }
                                        ?></td>
                                    <td>
                                        <?php
                                        if ($lis->Can > $lis->Min) {
                                            echo '<font color="green">Ok</font>' ;
                                        };
                                        if ($lis->Can == 0) {
                                            echo '<font color="red">Sin Stock</font>';
                                        } else {
                                            if ($lis->Can < 0) {
                                                echo '<font color="red">Faltante: ' . $lis->Can * (-1) . ' unidad/es</font>';
                                            } else {
                                                if ($lis->Can <= $lis->Min && $lis->Can > 1) {
                                                    echo '<font color="orange">¡A punto de agotarse!</font>';
                                                }
                                                if ($lis->Can == 1) {
                                                    echo '<font color="red">¡Ultimo!</font>';
                                                }
                                            }
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo '$' . $Prec = number_format($lis->Prec, 2, '.', '') ?></td>
                                    <td>
                                        <a href='<?php echo base_url() ?>index.php/producto/agregar_existencia/<?php echo $lis->id_producto ?>' class="btn btn-info btn-circle fa fa-cubes" title="Agregar stock"></a>
                                        <a href='<?php echo base_url() ?>index.php/producto/editar/<?php echo $lis->id_producto ?>' class="btn btn-warning btn-circle fa fa-edit" title="Editar"></a>
                                        <?php
                                        if ($lis->Can <= 0) {
                                            echo '<p class="btn btn-danger btn-circle fa fa-ban" title="Sin Stock"></p>';
                                        } else {
                                            echo '<a href=' . base_url() . 'index.php/ventas/vender_paso1/' . $lis->id_producto . ' class="btn btn-success btn-circle fa fa-dollar" title="Vender"></a>';
                                        }
                                        ?>

                                    </td>
                                </tr>
                            <?php } ?> 
                        </tbody>
                    </table>
                    <!-- /.table-responsive -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div>
</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url() ?>vendor/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>dist/js/sb-admin-2.js"></script>

<!-- DataTables JavaScript -->
<script src="<?php echo base_url() ?>vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url() ?>vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>vendor/datatables-responsive/dataTables.responsive.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>dist/js/sb-admin-2.js"></script>

<!-- Page-Level Demo Scripts - Tables - Use for reference -->
<script>
    $(document).ready(function () {
        $('#dataTables-example').DataTable({
            responsive: true,
            "language": {
                "sProcessing": "Procesando...",
                "sLengthMenu": "Mostrar _MENU_ registros",
                "sZeroRecords": "Sin existencia",
                "sEmptyTable": "Ningún dato disponible en esta tabla",
                "sInfo": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                "sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
                "sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
                "sInfoPostFix": "",
                "sSearch": "Buscar:",
                "sUrl": "",
                "sInfoThousands": ",",
                "sLoadingRecords": "Cargando...",
                "oPaginate": {
                    "sFirst": "Primero",
                    "sLast": "Último",
                    "sNext": "Siguiente",
                    "sPrevious": "Anterior"
                },
                "oAria": {
                    "sSortAscending": ": Activar para ordenar la columna de manera ascendente",
                    "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                }}

        });
    });
</script>

</body>

</html>