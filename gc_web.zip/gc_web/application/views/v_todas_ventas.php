<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">Listado de todas las Ventas</h2>
                <div class="panel panel-info">
                    <div class="panel-heading"><h3 class="panel-title"> <?php echo count($listado) ?> ventas registradas.</h3></div>
                    <div class="panel-body">
                        <table class="table table-hover">
                            <tr>
                                <td><b>Codigo</b></td>
                                <td><b>Producto</b></td>
                                <td><b>Cantidad</b></td>
                                <td><b>Fecha y Hora</b></td>
                                <td><b>Forma de pago</b></td>
                                <td><b>Total</b></td>
                            </tr>
                            <?php foreach ($listado as $lis) { ?>
                                <tr>
                                    <td><?php echo $lis->Cod ?></td>
                                    <td><?php echo $lis->Nom ?></td>
                                    <td><?php echo $lis->Cant ?></td>
                                    <td>
                                        <?php
                                        echo date("d", strtotime($lis->fecha)) . '/';
                                        echo date("m", strtotime($lis->fecha)) . '/';
                                        echo date("Y", strtotime($lis->fecha)) . ' a las ';
                                        echo date("H", strtotime($lis->fecha)) . ':' . date("i", strtotime($lis->fecha)) . 'hs.';
                                        ?>
                                    </td>
                                    <td>
                                        <?php echo $lis->Fp ?>
                                    </td>
                                    <td>
                                        <?php
                                        if ($lis->recargo > 0) {
                                            $recargo = $lis->Prec * $lis->recargo / 100;
                                        } else {
                                            $recargo = 0;
                                        }
                                        if ($lis->descuento > 0) {
                                            $descuento = $lis->Prec * $lis->descuento / 100;
                                        } else {
                                            $descuento = 0;
                                        }
                                        echo '$' . $Total = number_format(($lis->Prec + $recargo - $descuento) * $lis->Cant, 2, '.', '');
                                        ?>
                                    </td>
                                    <td>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
</div>
</div>


<!-- jQuery -->
<script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url() ?>vendor/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>dist/js/sb-admin-2.js"></script>

</body>

</html>