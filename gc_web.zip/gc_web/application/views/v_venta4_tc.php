<!-- Page Content -->
<div id="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <br>
                <div class="panel panel-success">
                    <div class="panel-heading">
                        <center><b><h4>Venta: Paso 4</h4></b></center>
                    </div>
                    <div class="panel-body">
                        <div class="progress progress-striped active">
                            <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 75%">
                                <span class="sr-only">75%</span>
                            </div>
                        </div>
                        <hr>
                        <?php echo form_open() ?>
                        <?php foreach ($producto as $lis) { ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <p class="fa fa-dollar"></p><b> A pagar con <?php echo $lis->Fp ?>: </b>
                                    <?php
                                    if ($lis->recargo > 0) {
                                        $recargo = $lis->Prec * $lis->recargo / 100;
                                    } else {
                                        $recargo = 0;
                                    }
                                    if ($lis->descuento > 0) {
                                        $descuento = $lis->Prec * $lis->descuento / 100;
                                    } else {
                                        $descuento = 0;
                                    }
                                    echo '$' . $Total = number_format(($lis->Prec + $recargo - $descuento) * $lis->Cant, 2, '.', '');
                                    ?><br>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                                <div class = "col-lg-6">
                                    <p class="fa fa-scissors"></p> En <b><?php echo $lis->cuotas ?> </b> cuotas de:
                                    <?php
                                    if ($lis->recargo > 0) {
                                        $recargo = $lis->Prec * $lis->recargo / 100;
                                    } else {
                                        $recargo = 0;
                                    }
                                    if ($lis->descuento > 0) {
                                        $descuento = $lis->Prec * $lis->descuento / 100;
                                    } else {
                                        $descuento = 0;
                                    }
                                    echo '$<b>' . $Monto_cuota = number_format((($lis->Prec + $recargo - $descuento) * $lis->Cant) / $lis->cuotas, 2, '.', '') . '</b>';
                                    ?>
                                    <br>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                            </div>
                            <hr>
                            Ingrese los datos del cupon:
                            <div class="row">
                                <div class="col-lg-6">
                                    <p class="fa fa-credit-card"></p><b> Ultimos 4 digitos de la <?php echo $lis->Fp ?>: </b>
                                    <?php
                                    $ult_digitos = array(
                                        'name' => 'ult_digitos',
                                        'id' => 'ult_digitos',
                                        'placeholder' => 'Ultimos 4 digitos',
                                        'value' => set_value('ult_digitos', $datos[0]->ult_digitos),
                                    );
                                    ?>
                                        <?php echo form_input($ult_digitos) ?><br>
                                        <?php echo form_error('ult_digitos') ?>
                                </div>
                                <!--/.col-lg-6 (nested) -->
                                <div class = "col-lg-6">
                                    <p class="fa fa-check"></p><b> Codigo de autorizacion: </b>
                                    <?php
                                    $cod_aut = array(
                                        'name' => 'cod_aut',
                                        'id' => 'cod_aut',
                                        'placeholder' => 'Codigo de autorizacion',
                                        'value' => set_value('cod_aut', $datos[0]->cod_aut),
                                    );
                                    ?>
                                        <?php echo form_input($cod_aut) ?><br>
                                        <?php echo form_error('cod_aut') ?>

                                </div>
                                <!--/.col-lg-6 (nested) -->
                            </div>
                            <?php
                            echo form_hidden('codigo_unico', $lis->codigo_unico);
                            echo form_hidden('codigo', $lis->Cod);
                            echo form_hidden('id_producto', $lis->id_producto);
                            echo form_hidden('id_usuario', $lis->id_usuario);
                            echo form_hidden('precio', $lis->Prec);
                            echo form_hidden('monto_final', ($lis->Prec + $recargo - $descuento) * $lis->Cant);
                            ?>
                        <?php } ?>
                        <hr>
                        <p class="text-center">
                            <input type="button" class = "btn btn-info" value="Volver" name="volver" onclick="history.back()" />
                            <?php echo form_submit('btn', 'Confirmar Compra', 'class = "btn btn-success"') ?>
                        </p>
                        <?php echo form_close() ?>
                    </div>
                    <!--/.panel-body -->
                </div>
            </div>
            <!-- /.col-lg-12 -->
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->


<!-- jQuery -->
<script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo base_url() ?>vendor/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url() ?>dist/js/sb-admin-2.js"></script>

</body>

</html>